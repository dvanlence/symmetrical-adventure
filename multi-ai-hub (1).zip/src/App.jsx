import React from "react";

const tools = [
  {
    name: "ChatGPT",
    description: "IA de conversação poderosa da OpenAI.",
    link: "https://chat.openai.com",
    category: "Texto",
  },
  {
    name: "Claude",
    description: "Assistente IA da Anthropic.",
    link: "https://claude.ai",
    category: "Texto",
  },
  {
    name: "Perplexity",
    description: "Buscador com IA integrada.",
    link: "https://www.perplexity.ai",
    category: "Texto",
  },
  {
    name: "Midjourney",
    description: "Gere imagens incríveis com IA.",
    link: "https://www.midjourney.com",
    category: "Imagem",
  },
  {
    name: "DALL·E",
    description: "Criação de imagens por texto (OpenAI).",
    link: "https://openai.com/dall-e",
    category: "Imagem",
  },
  {
    name: "GitHub Copilot",
    description: "Assistente de código da Microsoft.",
    link: "https://github.com/features/copilot",
    category: "Código",
  },
];

const categories = ["Texto", "Imagem", "Código"];

export default function App() {
  return (
    <main className="min-h-screen bg-gray-50 p-6">
      <h1 className="text-3xl font-bold text-center mb-6">🌐 MultiAI Hub</h1>
      {categories.map((cat) => (
        <section key={cat} className="mb-8">
          <h2 className="text-2xl font-semibold mb-4">{cat}</h2>
          <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
            {tools
              .filter((t) => t.category === cat)
              .map((tool) => (
                <a
                  href={tool.link}
                  target="_blank"
                  rel="noopener noreferrer"
                  key={tool.name}
                  className="block border rounded-xl p-4 shadow-sm hover:shadow-lg transition"
                >
                  <h3 className="text-xl font-medium">{tool.name}</h3>
                  <p className="text-gray-600 text-sm">{tool.description}</p>
                </a>
              ))}
          </div>
        </section>
      ))}
      <footer className="text-center text-gray-500 text-sm mt-12">
        © {new Date().getFullYear()} MultiAI Hub. Todos os direitos reservados.
      </footer>
    </main>
  );
}
